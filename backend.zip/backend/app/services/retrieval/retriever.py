import json
import re
from pathlib import Path

from app.models.chunk import Chunk

from .embedding_service import EmbeddingService
from .faiss_store import VectorStore


class Retriever:

    def __init__(self):
        self.embedding_service = EmbeddingService()
        self.vector_store = None
        self.chunks = []

    # =========================================================
    # INDEX
    # =========================================================

    def index(self, chunks):

        if not chunks:
            raise ValueError("Cannot index an empty chunk list.")

        self.chunks = list(chunks)

        embeddings = self.embedding_service.embed_chunks(
            self.chunks
        )

        dimension = embeddings.shape[1]

        self.vector_store = VectorStore(
            dimension=dimension
        )

        self.vector_store.add(
            embeddings
        )

    # =========================================================
    # RETRIEVE
    # =========================================================

    def retrieve(
        self,
        query: str,
        top_k: int = 5,
        min_score: float = 0.0,
        document_id: str | None = None,
        mode: str = "general",
    ):

        if self.vector_store is None:
            raise RuntimeError(
                "Vector store has not been indexed."
            )

        if not self.chunks:
            return []

        query = query.strip()

        if not query:
            return []

        print(
            "\nRetriever:",
            "document_id =", document_id,
            "| mode =", mode
        )

        # -----------------------------------------------------
        # 1. TOKENIZE QUERY
        # -----------------------------------------------------

        query_tokens = self._tokenize(query)

        # -----------------------------------------------------
        # 2. QUERY EMBEDDING
        # -----------------------------------------------------

        query_embedding = (
            self.embedding_service.embed_query(query)
        )

        # -----------------------------------------------------
        # 3. SEARCH FAISS
        # -----------------------------------------------------

        semantic_scores, indices = (
            self.vector_store.search(
                query_embedding,
                len(self.chunks)
            )
        )

        # -----------------------------------------------------
        # 4. DOCUMENT SCORES
        # -----------------------------------------------------

        document_scores = {}

        for chunk in self.chunks:

            chunk_document_id = str(
                chunk.document_id
            )

            if chunk_document_id in document_scores:
                continue

            document_scores[chunk_document_id] = (
                self._document_match(
                    query_tokens,
                    chunk
                )
            )

        # -----------------------------------------------------
        # 5. BUILD CANDIDATES
        # -----------------------------------------------------

        candidates = []

        for semantic_score, index in zip(
            semantic_scores,
            indices
        ):

            if index == -1:
                continue

            if index >= len(self.chunks):
                continue

            chunk = self.chunks[index]

            chunk_document_id = str(
                chunk.document_id
            )

            metadata = chunk.metadata or {}

            title = str(
                metadata.get(
                    "document_title",
                    ""
                )
            )

            source_type = str(
                metadata.get(
                    "source_type",
                    ""
                )
            ).lower()

            is_uploaded = bool(
                metadata.get(
                    "uploaded",
                    False
                )
            )

            is_resume = self._is_resume(
                title,
                source_type
            )

            # =================================================
            # EXPLICIT DOCUMENT SCOPE
            # =================================================

            if document_id is not None:

                if (
                    chunk_document_id
                    != str(document_id)
                ):
                    continue

            # =================================================
            # PROGRAMME MODE
            # =================================================

            elif mode == "programme":

                if is_uploaded:
                    continue

                if is_resume:
                    continue

            # =================================================
            # RESUME MODE
            # =================================================

            elif mode == "resume":

                if not is_resume:
                    continue

            # =================================================
            # BOTH MODE
            # =================================================

            # In "both" mode nothing is excluded.

            # =================================================
            # SCORES
            # =================================================

            semantic_score = float(
                semantic_score
            )

            lexical_score = (
                self._lexical_score(
                    query_tokens,
                    chunk
                )
            )

            heading_score = (
                self._heading_score(
                    query_tokens,
                    chunk
                )
            )

            document_score = (
                document_scores.get(
                    chunk_document_id,
                    0.0
                )
            )

            phrase_score = (
                self._phrase_score(
                    query,
                    chunk
                )
            )

            # =================================================
            # FINAL SCORE
            # =================================================

            final_score = (
                0.45 * semantic_score
                + 0.20 * lexical_score
                + 0.15 * heading_score
                + 0.10 * document_score
                + 0.10 * phrase_score
            )

            # Strong explicit document scope.
            if document_id is not None:
                final_score += 0.25

            # Strong document-title match.
            elif document_score >= 1.0:
                final_score += 0.25

            candidates.append(
                {
                    "chunk": chunk,
                    "score": float(final_score),
                    "semantic_score": semantic_score,
                    "lexical_score": lexical_score,
                    "heading_score": heading_score,
                    "document_score": document_score,
                    "phrase_score": phrase_score,
                }
            )

        # =====================================================
        # 6. SORT
        # =====================================================

        candidates.sort(
            key=lambda x: x["score"],
            reverse=True
        )

        # =====================================================
        # 7. REMOVE WEAK RESULTS
        # =====================================================

        if candidates:

            best_score = candidates[0]["score"]

            dynamic_minimum = max(
                min_score,
                best_score * 0.45
            )

            candidates = [
                result
                for result in candidates
                if result["score"]
                >= dynamic_minimum
            ]

        # =====================================================
        # 8. DEDUPLICATE
        # =====================================================

        results = []

        seen = set()

        for result in candidates:

            chunk = result["chunk"]

            key = (
                str(chunk.document_id),
                str(chunk.heading),
                str(chunk.text).strip()
            )

            if key in seen:
                continue

            seen.add(key)

            results.append(result)

            if len(results) >= top_k:
                break

        # =====================================================
        # 9. DEBUG
        # =====================================================

        print(
            "\nFinal retrieval results:"
        )

        for result in results:

            chunk = result["chunk"]

            print(
                round(
                    result["score"],
                    4
                ),
                "| semantic:",
                round(
                    result["semantic_score"],
                    4
                ),
                "| lexical:",
                round(
                    result["lexical_score"],
                    4
                ),
                "| heading:",
                round(
                    result["heading_score"],
                    4
                ),
                "| document:",
                round(
                    result["document_score"],
                    4
                ),
                "| phrase:",
                round(
                    result["phrase_score"],
                    4
                ),
                "|",
                chunk.metadata.get(
                    "document_title",
                    ""
                ),
                "|",
                chunk.heading
            )

        return results

    # =========================================================
    # DOCUMENT MODE
    # =========================================================

    @staticmethod
    def _detect_document_mode(
        query: str
    ) -> str:

        text = query.lower()

        resume_terms = {
            "my resume",
            "my cv",
            "in my resume",
            "on my resume",
            "from my resume",
            "mentioned in my resume",
            "listed in my resume",
            "according to my resume",
        }

        programme_terms = {
            "programme",
            "program",
            "course",
            "curriculum",
            "hostel",
            "fee",
            "fees",
            "eligibility",
            "admission",
            "application",
            "placement",
            "faculty",
            "duration",
            "scholarship",
        }

        resume_match = any(
            term in text
            for term in resume_terms
        )

        programme_match = any(
            term in text
            for term in programme_terms
        )

        if (
            resume_match
            and programme_match
        ):
            return "both"

        if resume_match:
            return "resume"

        if programme_match:
            return "programme"

        return "general"

    # =========================================================
    # TARGET DOCUMENTS
    # =========================================================

    def _get_target_documents(
        self,
        document_mode: str,
        document_scores: dict
    ) -> set[str]:

        if document_mode in {
            "general",
            "both"
        }:
            return set()

        if document_mode == "resume":

            resume_documents = set()

            for document_id in document_scores:

                document_text = (
                    str(document_id)
                    .lower()
                )

                if (
                    "resume" in document_text
                    or "cv" in document_text
                ):
                    resume_documents.add(
                        document_id
                    )

            return resume_documents

        return set()

    # =========================================================
    # IS RESUME
    # =========================================================

    @staticmethod
    def _is_resume(
        title: str,
        source_type: str
    ) -> bool:

        title = title.lower()
        source_type = source_type.lower()

        return (
            "resume" in title
            or "cv" in title
            or source_type == "resume"
        )

    # =========================================================
    # TOKENIZATION
    # =========================================================

    @staticmethod
    def _tokenize(
        text: str
    ) -> set[str]:

        words = re.findall(
            r"[a-zA-Z0-9]+",
            text.lower()
        )

        stop_words = {
            "the",
            "is",
            "are",
            "a",
            "an",
            "and",
            "or",
            "of",
            "to",
            "in",
            "on",
            "for",
            "what",
            "which",
            "who",
            "how",
            "where",
            "when",
            "why",
            "my",
            "your",
            "their",
            "this",
            "that",
            "these",
            "those",
            "do",
            "does",
            "did",
            "tell",
            "me",
            "about",
            "give",
            "only",
            "mentioned",
            "listed",
            "according",
        }

        return {
            word
            for word in words
            if word not in stop_words
        }

    # =========================================================
    # DOCUMENT MATCH
    # =========================================================

    def _document_match(
        self,
        query_tokens: set[str],
        chunk: Chunk
    ) -> float:

        if not query_tokens:
            return 0.0

        metadata = (
            chunk.metadata or {}
        )

        title = str(
            metadata.get(
                "document_title",
                ""
            )
        )

        source = str(
            metadata.get(
                "source",
                ""
            )
        )

        document_text = (
            f"{title} {source}"
        )

        document_tokens = (
            self._tokenize(
                document_text
            )
        )

        if not document_tokens:
            return 0.0

        matches = (
            query_tokens
            &
            document_tokens
        )

        return (
            len(matches)
            /
            len(query_tokens)
        )

    # =========================================================
    # CHUNK TEXT MATCH
    # =========================================================

    def _lexical_score(
        self,
        query_tokens: set[str],
        chunk: Chunk
    ) -> float:

        if not query_tokens:
            return 0.0

        text_tokens = (
            self._tokenize(
                chunk.text
            )
        )

        if not text_tokens:
            return 0.0

        matches = (
            query_tokens
            &
            text_tokens
        )

        return (
            len(matches)
            /
            len(query_tokens)
        )

    # =========================================================
    # HEADING MATCH
    # =========================================================

    def _heading_score(
        self,
        query_tokens: set[str],
        chunk: Chunk
    ) -> float:

        if not query_tokens:
            return 0.0

        heading_tokens = (
            self._tokenize(
                chunk.heading
            )
        )

        if not heading_tokens:
            return 0.0

        matches = (
            query_tokens
            &
            heading_tokens
        )

        return (
            len(matches)
            /
            len(query_tokens)
        )

    # =========================================================
    # PHRASE MATCH
    # =========================================================

    def _phrase_score(
        self,
        query: str,
        chunk: Chunk
    ) -> float:

        query_text = (
            query
            .lower()
            .strip()
        )

        chunk_text = (
            f"{chunk.heading} "
            f"{chunk.text}"
        ).lower()

        if not query_text:
            return 0.0

        phrases = [
            "project names",
            "project name",
            "projects mentioned",
            "projects listed",
            "my resume",
            "my cv",
            "hostel fee",
            "hostel fees",
            "programme fee",
            "programme fees",
            "course fee",
            "course fees",
            "eligibility requirements",
            "admission requirements",
            "skills",
            "technologies",
        ]

        matches = 0

        for phrase in phrases:

            if (
                phrase in query_text
                and phrase in chunk_text
            ):
                matches += 1

        if matches == 0:
            return 0.0

        return min(
            1.0,
            matches / 2.0
        )

    # =========================================================
    # SAVE
    # =========================================================

    def save(
        self,
        directory: str
    ):

        if self.vector_store is None:
            raise RuntimeError(
                "Cannot save an unindexed retriever."
            )

        directory = Path(
            directory
        )

        directory.mkdir(
            parents=True,
            exist_ok=True
        )

        index_path = (
            directory
            /
            "faiss.index"
        )

        chunks_path = (
            directory
            /
            "chunks.json"
        )

        self.vector_store.save(
            str(index_path)
        )

        chunks_data = [
            chunk.model_dump()
            for chunk in self.chunks
        ]

        chunks_path.write_text(
            json.dumps(
                chunks_data,
                indent=2,
                ensure_ascii=False
            ),
            encoding="utf-8"
        )

    # =========================================================
    # LOAD
    # =========================================================

    def load(
        self,
        directory: str
    ):

        directory = Path(
            directory
        )

        index_path = (
            directory
            /
            "faiss.index"
        )

        chunks_path = (
            directory
            /
            "chunks.json"
        )

        if not index_path.exists():
            raise FileNotFoundError(
                f"FAISS index not found: {index_path}"
            )

        if not chunks_path.exists():
            raise FileNotFoundError(
                f"Chunks file not found: {chunks_path}"
            )

        dimension = (
            self.embedding_service
            .model
            .get_sentence_embedding_dimension()
        )

        self.vector_store = VectorStore(
            dimension=dimension
        )

        self.vector_store.load(
            str(index_path)
        )

        chunks_data = json.loads(
            chunks_path.read_text(
                encoding="utf-8"
            )
        )

        self.chunks = [
            Chunk(**chunk)
            for chunk in chunks_data
        ]