from sentence_transformers import SentenceTransformer

from app.models.chunk import Chunk


class EmbeddingService:

    def __init__(self):

        self.model = SentenceTransformer(
            "all-MiniLM-L6-v2"
        )

    def embed_text(self, text: str):

        return self.model.encode(
            text,
            normalize_embeddings=True
        )

    def embed_chunks(
        self,
        chunks: list[Chunk]
    ):

        texts = []

        for chunk in chunks:

            # Include structural information in the
            # embedding, not just the raw body text.
            text = (
                f"Heading: {chunk.heading}\n"
                f"{chunk.text}"
            )

            texts.append(text)

        return self.model.encode(
            texts,
            normalize_embeddings=True
        )

    def embed_query(self, query: str):

        return self.model.encode(
            query,
            normalize_embeddings=True
        )