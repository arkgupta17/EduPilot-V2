from app.core.config import GROQ_API_KEY

from app.services.retrieval.retriever import Retriever
from app.services.generator.query_rewriter import QueryRewriter
from app.services.generator.prompt_builder import PromptBuilder
from app.services.generator.response_generator import ResponseGenerator


class RAGPipeline:

    def __init__(self):

        self.retriever = Retriever()

        self.retriever.load(
            "data/index"
        )

        self.query_rewriter = QueryRewriter(
            GROQ_API_KEY
        )

        self.prompt_builder = PromptBuilder()

        self.generator = ResponseGenerator(
            GROQ_API_KEY
        )
    def reload_index(self):
     self.retriever = Retriever()
     self.retriever.load("data/index")
    # =====================================================
    # CONVERSATIONAL / NON-RAG QUERIES
    # =====================================================

    @staticmethod
    def _direct_response(query: str):

        q = query.lower().strip()

        greetings = {
            "hi",
            "hello",
            "hey",
            "hi edupilot",
            "hello edupilot",
            "hey edupilot",
        }

        thanks = {
            "thanks",
            "thank you",
            "thanks edupilot",
            "thank you edupilot",
            "thx",
            "ty",
        }

        if q in greetings:
            return "Hello! How can I help you?"

        if q in thanks:
            return "You're welcome! How can I help?"

        return None

    # =====================================================
    # INTENT DETECTION
    # =====================================================

    @staticmethod
    def _detect_intent(query: str) -> str:

        q = query.lower()

        # Comparison MUST be checked first.
        comparison_terms = [
            "align",
            "alignment",
            "match",
            "matches",
            "suitable",
            "suitability",
            "fit",
            "compare",
            "comparison",
            "relevant to me",
            "relevant for me",
            "how does my",
            "how do my",
        ]

        if any(
            term in q
            for term in comparison_terms
        ):
            return "comparison"

        # Resume / person.
        resume_terms = [
            "my resume",
            "my cv",
            "ark",
            "his resume",
            "his cv",
            "ark's",
            "ark has",
            "ark made",
            "ark's skills",
            "ark's projects",
            "ark's education",
            "ark's achievements",
            "ark's contribution",
            "ark's github",
            "ark's dsa",
            "ark's phone",
            "his github",
            "his phone",
            "his projects",
            "his skills",
        ]

        if any(
            term in q
            for term in resume_terms
        ):
            return "resume"

        # Programme.
        programme_terms = [
            "programme",
            "program",
            "curriculum",
            "course",
            "hostel",
            "hostel fee",
            "fees",
            "fee",
            "eligibility",
            "admission",
            "application",
            "duration",
            "placement",
            "placements",
            "faculty",
            "scholarship",
            "campus",
        ]

        if any(
            term in q
            for term in programme_terms
        ):
            return "programme"

        return "general"

    # =====================================================
    # QUERY EXPANSION
    # =====================================================

    @staticmethod
    def _expand_query(
        query: str,
        intent: str
    ) -> list[str]:

        q = query.lower()

        queries = [
            query
        ]

        # -------------------------------------------------
        # DSA / COMPETITIVE PROGRAMMING
        # -------------------------------------------------

        if any(
            term in q
            for term in [
                "dsa",
                "data structures",
                "algorithms",
                "good at dsa",
                "strong at dsa",
                "coding ability",
                "competitive programming",
            ]
        ):

            queries.extend([
                "DSA competitive programming LeetCode",
                "250+ DSA problems LeetCode rating",
                "Achievements Certifications competitive programming",
            ])

        # -------------------------------------------------
        # OPEN SOURCE / GSOC / GITHUB CONTRIBUTIONS
        # -------------------------------------------------

        if any(
            term in q
            for term in [
                "gsoc",
                "open source",
                "open-source",
                "github contribution",
                "github contributions",
                "open source contribution",
                "contribution",
                "contributions",
                "julia",
                "julialang",
                "dataframes.jl",
            ]
        ):

            queries.extend([
                "Open Source Contributions",
                "JuliaLang Julia DataFrames.jl contributions",
                "GitHub open source contributions",
            ])

        # -------------------------------------------------
        # PROJECTS
        # -------------------------------------------------

        if (
            "project" in q
            or "projects" in q
        ):

            queries.extend([
                "Projects",
                "projects in Ark resume",
                "Zenness EduPilot projects",
            ])

        # -------------------------------------------------
        # TECHNICAL SKILLS
        # -------------------------------------------------

        if (
            "skill" in q
            or "skills" in q
            or "technology" in q
            or "technologies" in q
            or "tech stack" in q
        ):

            queries.extend([
                "Technical Skills",
                "programming languages frameworks machine learning tools",
            ])

        # -------------------------------------------------
        # EDUCATION
        # -------------------------------------------------

        if any(
            term in q
            for term in [
                "education",
                "degree",
                "college",
                "university",
                "btech",
                "study",
                "studies",
            ]
        ):

            queries.append(
                "Education"
            )

        # -------------------------------------------------
        # ACHIEVEMENTS / HACKATHONS
        # -------------------------------------------------

        if any(
            term in q
            for term in [
                "achievement",
                "achievements",
                "hackathon",
                "won",
                "award",
                "certification",
                "certifications",
            ]
        ):

            queries.append(
                "Achievements & Certifications"
            )

        # -------------------------------------------------
        # GITHUB PROFILE
        # -------------------------------------------------

        if (
            "github" in q
            and "project" not in q
            and "projects" not in q
            and "contribution" not in q
        ):

            queries.extend([
                "GitHub profile URL",
                "LinkedIn GitHub LeetCode contact information",
                "Ark Gupta GitHub",
            ])

        # -------------------------------------------------
        # PHONE / CONTACT
        # -------------------------------------------------

        if any(
            term in q
            for term in [
                "phone",
                "phone number",
                "mobile",
                "contact number",
                "email",
                "email address",
            ]
        ):

            queries.extend([
                "Ark Gupta contact information",
                "phone email LinkedIn GitHub",
            ])

        # -------------------------------------------------
        # COMPARISON
        # -------------------------------------------------

        if intent == "comparison":

            queries.extend([
                "Technical Skills",
                "Projects",
                "Relevant Coursework",
                "programme curriculum",
                "programme courses",
                "programme requirements",
            ])

        # -------------------------------------------------
        # REMOVE DUPLICATES
        # -------------------------------------------------

        unique = []
        seen = set()

        for item in queries:

            item = item.strip()

            key = item.lower()

            if (
                item
                and key not in seen
            ):

                seen.add(key)
                unique.append(item)

        return unique

    # =====================================================
    # DOCUMENT IDENTIFICATION
    # =====================================================

    @staticmethod
    def _is_resume(result) -> bool:

        chunk = result["chunk"]

        metadata = (
            chunk.metadata
            or {}
        )

        title = str(
            metadata.get(
                "document_title",
                ""
            )
        ).lower()

        source_type = str(
            metadata.get(
                "source_type",
                ""
            )
        ).lower()

        return (
            "resume" in title
            or "cv" in title
            or source_type == "resume"
        )

    # =====================================================
    # MERGE RESULTS
    # =====================================================

    @staticmethod
    def _merge_results(
        result_sets
    ):

        merged = {}

        for results in result_sets:

            for result in results:

                chunk = result["chunk"]

                key = (
                    str(chunk.document_id),
                    str(chunk.heading),
                    str(chunk.text),
                )

                if (
                    key not in merged
                    or result["score"]
                    > merged[key]["score"]
                ):

                    merged[key] = result

        return sorted(
            merged.values(),
            key=lambda x: x["score"],
            reverse=True,
        )

    # =====================================================
    # FILTER BY INTENT
    # =====================================================

    def _filter_results(
        self,
        results,
        intent: str,
        query: str,
    ):

        if not results:
            return []

        # -------------------------------------------------
        # Comparison needs BOTH documents.
        # -------------------------------------------------

        if intent == "comparison":
            return results

        # -------------------------------------------------
        # Personal/resume query.
        # -------------------------------------------------

        if intent == "resume":

            resume_results = [
                r
                for r in results
                if self._is_resume(r)
            ]

            if resume_results:
                return resume_results

        # -------------------------------------------------
        # Programme query.
        # -------------------------------------------------

        if intent == "programme":

            programme_results = [
                r
                for r in results
                if not self._is_resume(r)
            ]

            if programme_results:
                return programme_results

        return results

    # =====================================================
    # ANSWER
    # =====================================================

    def answer(
        self,
        query: str,
        history: list[dict] | None = None,
        top_k: int = 5,
        document_id: str | None = None,
    ):

        # -------------------------------------------------
        # Initialize history
        # -------------------------------------------------

        if history is None:
            history = []

        # -------------------------------------------------
        # Always show document scope in logs
        # -------------------------------------------------

        print(
            "\nDocument scope:",
            document_id
        )

        # -------------------------------------------------
        # Reload current knowledge base
        # -------------------------------------------------

        try:

            self.retriever.load(
                "data/index"
            )

        except Exception as exc:

            print(
                "Knowledge base reload failed:",
                exc
            )

        query = query.strip()

        if not query:

            return {
                "answer": "Please ask me a question.",
                "sources": [],
            }

        # -------------------------------------------------
        # 1. Conversational gate
        # -------------------------------------------------

        direct = self._direct_response(
            query
        )

        if direct:

            return {
                "answer": direct,
                "sources": [],
            }

        # -------------------------------------------------
        # 2. Rewrite FIRST
        # -------------------------------------------------

        search_query = (
            self.query_rewriter.rewrite(
                query,
                history,
            )
        )

        if not search_query:
            search_query = query

        print(
            "\n================================"
        )

        print(
            "Original query:",
            query,
        )

        print(
            "Search query:",
            search_query,
        )

        # -------------------------------------------------
        # 3. Intent after rewriting
        # -------------------------------------------------

        intent = self._detect_intent(
            search_query
        )

        print(
            "Intent:",
            intent,
        )

        # -------------------------------------------------
        # 4. Expand query
        # -------------------------------------------------

        retrieval_queries = (
            self._expand_query(
                search_query,
                intent,
            )
        )

        print(
            "Retrieval queries:"
        )

        for item in retrieval_queries:

            print(
                " -",
                item,
            )

        # -------------------------------------------------
        # 5. Retrieve broad candidate pool
        # -------------------------------------------------

        result_sets = []

        retrieval_k = max(
            15,
            top_k * 3,
        )

        for retrieval_query in retrieval_queries:

         results = self.retriever.retrieve(
        retrieval_query,
        top_k=retrieval_k,
        document_id=document_id,
        mode=(
            "programme"
            if intent == "programme"
            else "resume"
            if intent == "resume"
            else "general"
        ),
    )

         result_sets.append(
        results
    )

        # -------------------------------------------------
        # 6. Merge
        # -------------------------------------------------

        results = self._merge_results(
            result_sets
        )

        # -------------------------------------------------
        # 9. Deduplicate by document + heading
        # -------------------------------------------------

        unique = {}

        for result in results:

            chunk = result["chunk"]

            key = (
                str(chunk.document_id),
                str(chunk.heading),
            )

            if (
                key not in unique
                or result["score"]
                > unique[key]["score"]
            ):

                unique[key] = result

        results = sorted(
            unique.values(),
            key=lambda x: x["score"],
            reverse=True,
        )

        # -------------------------------------------------
        # 10. Keep useful evidence
        # -------------------------------------------------

        results = results[
            :max(top_k, 8)
        ]

        print(
            "\nFinal evidence:"
        )

        for result in results:

            chunk = result["chunk"]

            print(
                round(
                    result["score"],
                    4,
                ),
                "|",
                chunk.metadata.get(
                    "document_title"
                ),
                "|",
                chunk.heading,
            )

        # -------------------------------------------------
        # 11. Nothing retrieved
        # -------------------------------------------------

        if not results:

            return {
                "answer": (
                    "I don't know based on "
                    "the available information."
                ),
                "sources": [],
            }

        # -------------------------------------------------
        # 12. Generate grounded answer
        #
        # IMPORTANT:
        # Retrieval uses search_query.
        # The LLM receives the ORIGINAL user question.
        # -------------------------------------------------

        chunks = [
            result["chunk"]
            for result in results
        ]

        prompt = self.prompt_builder.build(
            query,
            chunks,
        )

        answer = self.generator.generate(
            prompt
        )

        # -------------------------------------------------
        # 13. Detect unsupported/unknown answer
        # -------------------------------------------------

        unknown_phrases = [
            "i don't know based on the available information",
            "i don't know based on the provided context",
            "the information is not available",
            "not available in the provided context",
            "not available in the provided programme data",
            "cannot be determined from the provided context",
            "i cannot determine this from the provided context",
        ]

        answer_lower = (
            answer
            .lower()
            .strip()
        )

        if any(
            phrase in answer_lower
            for phrase in unknown_phrases
        ):

            return {
                "answer": answer,
                "sources": [],
            }

        # -------------------------------------------------
        # 14. Sources
        # -------------------------------------------------

        sources = []

        seen = set()

        for result in results:

            chunk = result["chunk"]

            key = (
                str(chunk.document_id),
                str(chunk.heading),
            )

            if key in seen:
                continue

            seen.add(key)

            sources.append(
                {
                    "heading": chunk.heading,
                    "url": chunk.document_id,
                    "score": round(
                        result["score"],
                        4,
                    ),
                }
            )

        print(
            "================================\n"
        )

        return {
            "answer": answer,
            "sources": sources,
        }