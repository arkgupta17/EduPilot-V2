from urllib.parse import urljoin, urlparse

from playwright.async_api import async_playwright

class WebCrawler:
    """
    Crawls a website and returns raw HTML.
    Responsible only for fetching pages and discovering relevant links.
    """

    def __init__(self):
        self.playwright = None
        self.browser = None
        self.context = None
        self.page = None

    SKIP_KEYWORDS = [
        "blog",
        "news",
        "events",
        "careers",
        "login",
        "contact",
        "about-us",
    ]

    ALLOWED_KEYWORDS = [
        "program",
        "course",
        "curriculum",
        "admission",
        "fees",
        "faculty",
        "placement",
        "career",
        "syllabus",
        "ai",
        "management",
        "applied",
        "agentic",
    ]
    async def start(self):

         self.playwright = await async_playwright().start()

         self.browser = await self.playwright.chromium.launch(
         headless=True
         )

         self.context = await self.browser.new_context(
         user_agent="Mozilla/5.0"
         )

         self.page = await self.context.new_page()

    async def close(self):

         if self.browser:
           await self.browser.close()

         if self.playwright:
           await self.playwright.stop()


    async def crawl(self, url: str) -> str:
        """
        Fetch a webpage and return its raw HTML.
        """
        await self.page.goto(
        url,
        wait_until="domcontentloaded"
        )

        return await self.page.content()


    async def find_subpages(self, url: str) -> list[str]:

            await self.page.goto(
                url,
                wait_until="domcontentloaded"
            )
        
            links = await self.page.evaluate("""
                () => Array.from(document.querySelectorAll("a[href]"))
                          .map(a => a.getAttribute("href"))
            """)
        
            return self.filter_relevant_urls(links, url)
        
            def filter_relevant_urls(self, links: list[str], base_url: str) -> list[str]:
                """
                Filter only useful academic pages belonging to the same website.
                """
        
                base_domain = urlparse(base_url).netloc
        
                filtered_links = []
                visited = {base_url.rstrip("/")}
        
                for link in links:
        
                    if not link or link.startswith("#"):
                        continue
        
                    full_url = urljoin(base_url, link)
                    parsed = urlparse(full_url)
        
                    if parsed.netloc != base_domain:
                        continue
        
                    if any(
                        keyword in full_url.lower()
                        for keyword in self.SKIP_KEYWORDS
                    ):
                        continue
        
                    if not any(
                        keyword in parsed.path.lower()
                        for keyword in self.ALLOWED_KEYWORDS
                    ):
                        continue
        
                    clean_url = full_url.split("#")[0].rstrip("/")
        
                    if clean_url in visited:
                        continue
        
                    visited.add(clean_url)
                    filtered_links.append(clean_url)
        
                return filtered_links

            