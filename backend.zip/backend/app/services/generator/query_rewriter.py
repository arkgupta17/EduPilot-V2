import re

from groq import Groq


class QueryRewriter:

    def __init__(
        self,
        api_key: str
    ):
        self.client = Groq(
            api_key=api_key
        )

    # =====================================================
    # BUILD CONVERSATION
    # =====================================================

    @staticmethod
    def _build_conversation(
        history: list[dict]
    ) -> str:

        if not history:
            return ""

        messages = []

        for message in history[-10:]:

            role = message.get(
                "role",
                "user"
            )

            content = str(
                message.get(
                    "content",
                    ""
                )
            ).strip()

            if not content:
                continue

            # Avoid sending huge responses.
            if len(content) > 3000:
                content = (
                    content[:3000]
                    + "..."
                )

            messages.append(
                f"{role}: {content}"
            )

        return "\n".join(
            messages
        )

    # =====================================================
    # EXTRACT ORDERED ENTITIES
    #
    # Example assistant response:
    #
    # 1. Zenness
    # 2. EduPilot
    #
    # Returns:
    #
    # {
    #     1: "Zenness",
    #     2: "EduPilot"
    # }
    # =====================================================

    @staticmethod
    def _extract_ordered_entities(
        history: list[dict]
    ) -> list[str]:

        if not history:
            return []

        # Search recent assistant responses first.
        assistant_messages = [
            str(
                message.get(
                    "content",
                    ""
                )
            ).strip()
            for message in reversed(
                history[-10:]
            )
            if message.get("role") == "assistant"
        ]

        for content in assistant_messages:

            if not content:
                continue

            entities = []

            # -------------------------------------------------
            # Pattern:
            #
            # 1. Zenness
            # 2. EduPilot
            #
            # Also handles:
            #
            # 1) Zenness
            # 2) EduPilot
            #
            # and:
            #
            # 1 - Zenness
            # 2 - EduPilot
            # -------------------------------------------------

            pattern = re.compile(
                r"(?m)^\s*"
                r"(\d+)"
                r"\s*[\.\)\-:]\s*"
                r"(.+?)"
                r"\s*$"
            )

            matches = pattern.findall(
                content
            )

            for number, value in matches:

                value = value.strip()

                # Remove markdown formatting.
                value = re.sub(
                    r"[*_`#]+",
                    "",
                    value
                ).strip()

                # Remove trailing explanation after
                # obvious separators.
                value = re.split(
                    r"\s+[—–-]\s+|\s+\|\s+",
                    value
                )[0].strip()

                # Ignore extremely long numbered paragraphs.
                if (
                    value
                    and len(value) <= 120
                ):
                    entities.append(
                        (
                            int(number),
                            value
                        )
                    )

            if entities:

                entities.sort(
                    key=lambda x: x[0]
                )

                return [
                    value
                    for _, value in entities
                ]

        return []

    # =====================================================
    # FIND LAST USER SUBJECT
    # =====================================================

    @staticmethod
    def _find_previous_subject(
        history: list[dict]
    ) -> str | None:

        if not history:
            return None

        # Look backwards for a useful user subject.
        for message in reversed(
            history[-10:]
        ):

            if message.get("role") != "user":
                continue

            content = str(
                message.get(
                    "content",
                    ""
                )
            ).strip()

            if not content:
                continue

            lower = content.lower()

            # Resume subject
            if (
                "resume" in lower
                or "cv" in lower
            ):
                return "Ark's resume"

            # Programme subject
            if (
                "programme" in lower
                or "program" in lower
                or "course" in lower
            ):
                return "the programme"

            # Ark/person subject
            if (
                "ark" in lower
                or "profile" in lower
            ):
                return "Ark"

        return None

    # =====================================================
    # REFERENCE HINTS
    # =====================================================

    def _build_reference_hints(
        self,
        query: str,
        history: list[dict]
    ) -> str:

        if not history:
            return ""

        lower = query.lower()

        ordered_entities = (
            self._extract_ordered_entities(
                history
            )
        )

        hints = []

        # -------------------------------------------------
        # First / second / third
        # -------------------------------------------------

        ordinal_patterns = [
            (
                r"\bfirst\b",
                0
            ),
            (
                r"\bsecond\b",
                1
            ),
            (
                r"\bthird\b",
                2
            ),
            (
                r"\bfourth\b",
                3
            )
        ]

        for pattern, index in ordinal_patterns:

            if re.search(
                pattern,
                lower
            ):

                if index < len(
                    ordered_entities
                ):

                    hints.append(
                        f'The "{pattern.strip(r"\\b")}" item '
                        f"refers to: "
                        f"{ordered_entities[index]}"
                    )

        # -------------------------------------------------
        # Explicit "first project"
        # -------------------------------------------------

        if (
            re.search(
                r"\bfirst\s+project\b",
                lower
            )
            and ordered_entities
        ):

            hints.append(
                "The first project is: "
                + ordered_entities[0]
            )

        if (
            re.search(
                r"\bsecond\s+project\b",
                lower
            )
            and len(
                ordered_entities
            ) >= 2
        ):

            hints.append(
                "The second project is: "
                + ordered_entities[1]
            )

        # -------------------------------------------------
        # "the other project"
        # -------------------------------------------------

        if (
            "other project" in lower
            and ordered_entities
        ):

            hints.append(
                "Use the other project from "
                "the previously listed projects."
            )

        # -------------------------------------------------
        # Pronouns
        # -------------------------------------------------

        if re.search(
            r"\b(he|him|his)\b",
            lower
        ):

            subject = (
                self._find_previous_subject(
                    history
                )
            )

            if subject:

                hints.append(
                    f'Pronoun reference "{query}" '
                    f"refers to: {subject}"
                )

        # -------------------------------------------------
        # Generic "this/that project"
        # -------------------------------------------------

        if re.search(
            r"\b(this|that)\s+project\b",
            lower
        ):

            if ordered_entities:

                # Usually the immediately preceding
                # discussed project is the last entity
                # in the list.
                hints.append(
                    "The project reference should "
                    "be resolved using the immediately "
                    "discussed project."
                )

        if not hints:
            return ""

        return (
            "\nREFERENCE RESOLUTION HINTS:\n"
            + "\n".join(
                f"- {hint}"
                for hint in hints
            )
        )

    # =====================================================
    # REWRITE
    # =====================================================

    def rewrite(
        self,
        query: str,
        history: list[dict]
    ) -> str:

        query = query.strip()

        if not query:
            return query

        # -------------------------------------------------
        # No history
        # -------------------------------------------------

        if not history:
            return query

        conversation = (
            self._build_conversation(
                history
            )
        )

        if not conversation:
            return query

        # -------------------------------------------------
        # Deterministic reference hints
        # -------------------------------------------------

        reference_hints = (
            self._build_reference_hints(
                query,
                history
            )
        )

        prompt = f"""
You are the query-understanding component of EduPilot.

Your ONLY job is to convert the latest user message into
ONE standalone retrieval query.

You are NOT answering the user.

You are NOT summarizing the conversation.

You are NOT inventing information.

You are resolving references.

CONVERSATION:
{conversation}

LATEST USER MESSAGE:
{query}

{reference_hints}

=========================================================
REFERENCE RESOLUTION
=========================================================

The conversation may contain ordered entities such as:

1. Zenness
2. EduPilot

If the latest user asks:

"tell me about the first one"

the output MUST refer to Zenness.

If the latest user asks:

"tell me about the second one"

the output MUST refer to EduPilot.

If explicit reference-resolution hints are provided above,
follow them.

Do NOT replace an explicitly identified entity with a
generic phrase such as "the first project".

=========================================================
IMPORTANT FOLLOW-UP RULES
=========================================================

Resolve:

- it
- they
- them
- this
- that
- those
- he
- him
- his
- the first one
- the second one
- the third one
- the first project
- the second project
- the previous one
- the above
- the other one

Preserve the actual subject from the conversation.

=========================================================
DOCUMENT CONTEXT
=========================================================

Preserve document context such as:

- my resume
- my CV
- my profile
- the uploaded PDF
- the programme
- the programme website

when relevant.

=========================================================
USER CONSTRAINTS
=========================================================

Preserve constraints such as:

- only names
- only projects
- only technologies
- briefly
- list all
- compare
- explain
- fees only
- eligibility only

=========================================================
EXAMPLES
=========================================================

Conversation:

User:
What projects are mentioned in my resume?

Assistant:
1. Zenness: Full-Stack Mental Health Platform
2. EduPilot: AI-Powered Course Assistant

Latest:
Tell me about the second one.

Output:
EduPilot project in Ark's resume

--------------------------------------------

Conversation:

User:
What projects are mentioned in my resume?

Assistant:
1. Zenness: Full-Stack Mental Health Platform
2. EduPilot: AI-Powered Course Assistant

Latest:
Tell me about the first project.

Output:
Zenness project in Ark's resume

--------------------------------------------

Conversation:

User:
Tell me about Ark.

Assistant:
Ark is a B.Tech student with projects including Zenness and EduPilot.

Latest:
What projects has he made?

Output:
projects made by Ark mentioned in his resume

--------------------------------------------

Conversation:

User:
What are the projects in my resume?

Assistant:
1. Zenness
2. EduPilot

Latest:
Give only their technologies.

Output:
technologies used in Zenness and EduPilot projects in Ark's resume

--------------------------------------------

Conversation:

User:
What is the programme duration?

Assistant:
The programme duration is 15 months.

Latest:
What about the eligibility?

Output:
eligibility requirements for the programme

=========================================================
RULES
=========================================================

1. Preserve the exact intent of the latest user message.

2. Resolve references using the conversation.

3. Use explicit reference-resolution hints when available.

4. Preserve document context.

5. Preserve user constraints.

6. Do not answer the question.

7. Do not invent facts.

8. Do not add information absent from the conversation.

9. If the latest query is already standalone,
   return it with minimal modification.

10. Return ONLY the final standalone search query.

11. Do not output explanations.

12. Do not output labels.

13. Do not output quotation marks.

FINAL SEARCH QUERY:
"""

        try:

            response = (
                self.client
                .chat.completions.create(
                    model="llama-3.1-8b-instant",
                    messages=[
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    temperature=0,
                    max_tokens=120
                )
            )

            rewritten = (
                response
                .choices[0]
                .message
                .content
                .strip()
            )

        except Exception as exc:

            print(
                "Query rewriting failed:",
                exc
            )

            return query

        # -------------------------------------------------
        # Cleanup
        # -------------------------------------------------

        prefixes = [
            "Rewritten query:",
            "Standalone search query:",
            "Search query:",
            "Final search query:"
        ]

        for prefix in prefixes:

            if rewritten.lower().startswith(
                prefix.lower()
            ):

                rewritten = rewritten[
                    len(prefix):
                ].strip()

        # Remove accidental quotes.
        if (
            len(rewritten) >= 2
            and rewritten[0] == '"'
            and rewritten[-1] == '"'
        ):

            rewritten = (
                rewritten[1:-1]
                .strip()
            )

        if not rewritten:
            return query

        if len(rewritten) > 500:
            return query

        print(
            "\nQuery Rewriter:"
        )
        print(
            "Original:",
            query
        )
        print(
            "Rewritten:",
            rewritten
        )

        return rewritten