from pathlib import Path
import shutil
import uuid

from fastapi import APIRouter, UploadFile, File, HTTPException

from app.services.processor.pdf_processor import PDFProcessor
from app.services.processor.document_chunker import DocumentChunker
from app.services.retrieval.retriever import Retriever

# NOTE: The import is intentionally left as-is for the project structure.
# If the language server still flags it, ensure the package is installed
# with the project root on PYTHONPATH.


router = APIRouter()


UPLOAD_DIR = Path("data/uploads")
INDEX_DIR = "data/index"

ALLOWED_EXTENSIONS = {
    ".pdf",
    ".docx",
    ".txt",
    ".md",
    ".pptx",
    ".xlsx",
    ".csv",
}

MAX_FILE_SIZE = 25 * 1024 * 1024  # 25 MB


@router.post("/documents/upload")
async def upload_document(
    file: UploadFile = File(...)
):

    # =====================================================
    # 1. VALIDATE FILE
    # =====================================================

    if not file.filename:

        raise HTTPException(
            status_code=400,
            detail="No file was provided."
        )

    extension = Path(
        file.filename
    ).suffix.lower()

    if extension not in ALLOWED_EXTENSIONS:

        raise HTTPException(
            status_code=400,
            detail=(
                "Unsupported file type. "
                "Supported formats: PDF, DOCX, TXT, MD, "
                "PPTX, XLSX and CSV."
            )
        )

    # -----------------------------------------------------
    # Current ingestion pipeline supports PDF processing.
    # -----------------------------------------------------

    if extension != ".pdf":

        raise HTTPException(
            status_code=400,
            detail=(
                "Document ingestion currently supports "
                "PDF files only."
            )
        )

    # =====================================================
    # 2. CREATE DOCUMENT ID
    # =====================================================

    document_id = uuid.uuid4().hex

    document_dir = (
        UPLOAD_DIR / document_id
    )

    document_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    file_path = (
        document_dir / file.filename
    )

    # =====================================================
    # 3. SAVE UPLOADED FILE
    # =====================================================

    total_size = 0

    try:

        with file_path.open("wb") as buffer:

            while True:

                data = await file.read(
                    1024 * 1024
                )

                if not data:
                    break

                total_size += len(data)

                if total_size > MAX_FILE_SIZE:

                    file_path.unlink(
                        missing_ok=True
                    )

                    raise HTTPException(
                        status_code=413,
                        detail=(
                            "File size cannot exceed 25 MB."
                        )
                    )

                buffer.write(data)

    except HTTPException:
        raise

    except Exception as exc:

        shutil.rmtree(
            document_dir,
            ignore_errors=True
        )

        raise HTTPException(
            status_code=500,
            detail=(
                "Failed to save the uploaded document."
            )
        ) from exc

    # =====================================================
    # 4. PROCESS PDF
    # =====================================================

    try:

        pdf_processor = PDFProcessor()

        document = pdf_processor.process(
            str(file_path)
        )

    except Exception as exc:

        shutil.rmtree(
            document_dir,
            ignore_errors=True
        )

        raise HTTPException(
            status_code=500,
            detail=(
                "The file was uploaded, but PDF "
                "processing failed."
            )
        ) from exc

    # =====================================================
    # 5. CREATE CHUNKS
    # =====================================================

    try:

        chunker = DocumentChunker()

        new_chunks = chunker.create_chunks(
            document
        )

    except Exception as exc:

        shutil.rmtree(
            document_dir,
            ignore_errors=True
        )

        raise HTTPException(
            status_code=500,
            detail=(
                "The PDF was processed, but "
                "document chunking failed."
            )
        ) from exc

    if not new_chunks:

        shutil.rmtree(
            document_dir,
            ignore_errors=True
        )

        raise HTTPException(
            status_code=422,
            detail=(
                "No readable text could be extracted "
                "from the uploaded PDF."
            )
        )

    # =====================================================
    # 6. ASSIGN THE UPLOAD DOCUMENT ID TO EVERY CHUNK
    # =====================================================
    #
    # This is CRITICAL.
    #
    # The document ID returned to the frontend must be
    # exactly the same ID stored inside every chunk.
    #
    # Otherwise:
    #
    # frontend document_id
    #        !=
    # chunk.document_id
    #
    # and document-scoped retrieval will return zero
    # results.
    #
    # =====================================================

    for chunk in new_chunks:

        chunk.document_id = document_id

        if chunk.metadata is None:
            chunk.metadata = {}

        chunk.metadata.update(
            {
                "source_type": "pdf",
                "source": str(file_path),
                "document_title": file_path.stem,
                "document_id": document_id,
                "filename": file.filename,
                "uploaded": True,
            }
        )

    # =====================================================
    # 7. LOAD EXISTING KNOWLEDGE BASE
    # =====================================================
    #
    # IMPORTANT:
    #
    # Do NOT replace the existing programme/resume
    # knowledge base with this upload.
    #
    # We append the uploaded document to the existing
    # knowledge base.
    #
    # =====================================================

    try:

        retriever = Retriever()

        retriever.load(
            INDEX_DIR
        )

        existing_chunks = list(
            retriever.chunks
        )

    except Exception as exc:

        print(
            "Existing knowledge base could not be loaded:",
            exc
        )

        existing_chunks = []

    # =====================================================
    # 8. GIVE NEW CHUNKS UNIQUE IDS
    # =====================================================

    start_id = len(
        existing_chunks
    )

    for index, chunk in enumerate(
        new_chunks
    ):

        chunk.id = (
            start_id + index
        )

    all_chunks = (
        existing_chunks +
        new_chunks
    )

    # =====================================================
    # 9. REBUILD FAISS INDEX
    # =====================================================

    try:

        retriever = Retriever()

        retriever.index(
            all_chunks
        )

        Path(INDEX_DIR).mkdir(
            parents=True,
            exist_ok=True
        )

        retriever.save(
            INDEX_DIR
        )

    except Exception as exc:

        shutil.rmtree(
            document_dir,
            ignore_errors=True
        )

        raise HTTPException(
            status_code=500,
            detail=(
                "The document was processed, but "
                "indexing failed."
            )
        ) from exc

    # =====================================================
    # 10. VERIFY THE NEW DOCUMENT IS IN THE INDEX
    # =====================================================

    try:

        verification = Retriever()

        verification.load(
            INDEX_DIR
        )

        uploaded_chunks = [
            chunk
            for chunk in verification.chunks
            if str(
                chunk.document_id
            ) == str(document_id)
        ]

        if not uploaded_chunks:

            raise RuntimeError(
                "Uploaded document was not found "
                "in the saved knowledge base."
            )

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "The document was uploaded, but "
                "knowledge-base verification failed."
            )
        ) from exc

    # =====================================================
    # 11. SUCCESS
    # =====================================================

    return {
        "document_id": document_id,
        "filename": file.filename,
        "file_type": extension.lstrip("."),
        "size_bytes": total_size,
        "chunks": len(uploaded_chunks),
        "total_indexed_chunks": len(
            verification.chunks
        ),
        "status": "indexed",
        "message": (
            f"{file.filename} uploaded and indexed "
            "successfully. You can now ask questions "
            "about the uploaded document."
        ),
    }